# PASTIS-like MMSegmentation Project

适用版本：`mmsegmentation==1.2.2`。  
任务：语义分割。图片为 `.jpg`，标签为 `.png`。标签值 `0..18` 为有效类别，`19` 为 void label。

本工程默认将标签中的 `19` 转成 `255`，并在 MMSeg 中作为 `ignore_index` 处理，因此模型输出类别数是 `19`，不是 `20`。

## 1. 数据目录

假设数据根目录为：

```text
data/pastis_jpg/
├── train_images/
│   ├── xxx.jpg
│   └── ...
├── val_images/
├── test_images/
├── train_labels/
│   ├── xxx.png
│   └── ...
├── val_labels/
└── test_labels/
```

要求图片和标签同名不同后缀，例如：

```text
train_images/123.jpg
train_labels/123.png
```

## 2. 安装

建议在你已经装好 PyTorch / CUDA 的环境中执行：

```bash
pip install -U openmim
mim install mmengine
mim install "mmcv>=2.0.0"
pip install "mmsegmentation==1.2.2"
pip install "mmpretrain>=1.2.0"
pip install pillow numpy
```

进入本工程目录后执行：

```bash
pip install -e .
```

如果你不想安装为包，也可以在工程根目录直接运行本工程 `tools/*.py`，脚本会自动把工程根目录加入 `PYTHONPATH`。

## 3. 检查数据

```bash
python tools/check_dataset.py --data-root data/pastis_jpg
```

它会检查：

- `train/val/test` 图片和标签数量；
- 是否存在同名 `.jpg` / `.png` 不匹配；
- 图片与标签尺寸是否一致；
- 标签值是否只包含 `0..19`。

## 4. 可视化原始标签

```bash
python tools/visualize_dataset.py \
  --data-root data/pastis_jpg \
  --split train \
  --out-dir outputs/gt_vis \
  --max-num 50
```

输出图片从左到右依次为：原图、标签伪彩色、叠加图。

## 5. 训练

### 配置 1：SwinV2-Base + UPerNet

```bash
python tools/train.py configs/pastis_upernet_swinv2_base.py \
  --work-dir work_dirs/pastis_upernet_swinv2_base \
  --amp \
  --cfg-options data_root=data/pastis_jpg
```

### 配置 2：ViT-Base + UPerNet

```bash
python tools/train.py configs/pastis_upernet_vit_base.py \
  --work-dir work_dirs/pastis_upernet_vit_base \
  --amp \
  --cfg-options data_root=data/pastis_jpg
```

如果显存不足，先把配置文件里的：

```python
train_dataloader = dict(batch_size=2, ...)
```

改成：

```python
train_dataloader = dict(batch_size=1, ...)
```

或者把 `crop_size = (512, 512)` 改小，例如 `(256, 256)`。

继续训练：

```bash
python tools/train.py configs/pastis_upernet_swinv2_base.py \
  --work-dir work_dirs/pastis_upernet_swinv2_base \
  --resume
```

## 6. 测试

将 `CHECKPOINT` 替换为训练得到的权重，例如 `best_mIoU_iter_40000.pth` 或 `iter_40000.pth`。

```bash
python tools/test.py configs/pastis_upernet_swinv2_base.py \
  work_dirs/pastis_upernet_swinv2_base/best_mIoU_iter_40000.pth \
  --cfg-options data_root=data/pastis_jpg
```

ViT 配置同理：

```bash
python tools/test.py configs/pastis_upernet_vit_base.py \
  work_dirs/pastis_upernet_vit_base/best_mIoU_iter_40000.pth \
  --cfg-options data_root=data/pastis_jpg
```

## 7. 推理与结果可视化

对单张图片推理：

```bash
python tools/infer.py configs/pastis_upernet_swinv2_base.py \
  work_dirs/pastis_upernet_swinv2_base/best_mIoU_iter_40000.pth \
  data/pastis_jpg/test_images/xxx.jpg \
  --out-dir outputs/infer_swinv2 \
  --device cuda:0
```

对一个文件夹批量推理：

```bash
python tools/infer.py configs/pastis_upernet_swinv2_base.py \
  work_dirs/pastis_upernet_swinv2_base/best_mIoU_iter_40000.pth \
  data/pastis_jpg/test_images \
  --out-dir outputs/infer_swinv2 \
  --device cuda:0
```

输出目录：

```text
outputs/infer_swinv2/
├── pred_masks/   # 原始预测标签，像素值 0..18
├── color_masks/  # 伪彩色预测图
└── overlays/     # 预测结果叠加到原图
```

## 8. 使用预训练权重

当前配置默认 `init_cfg=None`，即随机初始化 backbone。  
如果你有 MMPretrain 的 backbone 预训练权重，可以在配置文件中修改：

```python
model = dict(
    backbone=dict(
        init_cfg=dict(
            type='Pretrained',
            checkpoint='path/to/backbone_pretrain.pth',
            prefix='backbone.',
        )
    )
)
```

有些权重文件不需要 `prefix='backbone.'`，如果报很多 key 不匹配，可以改成 `prefix=''` 或按权重实际 key 调整。

## 9. 常见问题

### 9.1 为什么不是 `num_classes=20`？

因为 `19` 是 void label，不应参与训练和评估。本工程用 `PastisConvertVoid` 把 `19 -> 255`，MMSeg 默认会忽略 `255`。

### 9.2 标签是彩色 PNG 怎么办？

MMSeg 训练要求标签 PNG 的像素值是类别 ID，而不是 RGB 颜色。如果你的标签是彩色图，需要先转换为单通道索引图，像素值为 `0..19`。

### 9.3 测试集没有标签怎么办？

如果 `test_labels` 不存在，就不能计算 mIoU。你可以只用 `tools/infer.py` 对 `test_images` 做预测和可视化。

### 9.4 大图推理显存不足怎么办？

可以把配置里的：

```python
test_cfg=dict(mode='whole')
```

改成滑窗推理，例如：

```python
test_cfg=dict(mode='slide', crop_size=(512, 512), stride=(341, 341))
```
