import os
import json
import shutil

# ======================
# 路径设置
# ======================
json_path = r"G:\PASTIE_elev\PASTIS-R\metadata.geojson"

image_dir = r"G:\PASTIE_elev\processed_PASTIS_R\s2_rename"
label_dir = r"G:\PASTIE_elev\processed_PASTIS_R\labels_rename"

save_root = r"G:\PASTIE_elev\PASTIS_split"

# ======================
# fold划分
# ======================
train_folds = [1, 2, 3]
val_folds = [4]
test_folds = [5]

# ======================
# 创建文件夹
# ======================
sub_dirs = [
    "train_images",
    "train_labels",
    "val_images",
    "val_labels",
    "test_images",
    "test_labels"
]

for d in sub_dirs:
    os.makedirs(os.path.join(save_root, d), exist_ok=True)

# ======================
# 读取json
# ======================
with open(json_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# geojson通常数据在features里
features = data["features"]

# ======================
# 数据划分
# ======================
for item in features:

    props = item["properties"]

    file_id = str(props["id"])
    fold = int(props["Fold"])

    # 原始文件名
    image_name = f"{file_id}.jpg"

    # 标签文件名（默认与id同名）
    label_name = f"{file_id}.png"

    image_path = os.path.join(image_dir, image_name)
    label_path = os.path.join(label_dir, label_name)

    # 判断属于哪个集合
    if fold in train_folds:
        img_save = os.path.join(save_root, "train_images", image_name)
        lbl_save = os.path.join(save_root, "train_labels", label_name)

    elif fold in val_folds:
        img_save = os.path.join(save_root, "val_images", image_name)
        lbl_save = os.path.join(save_root, "val_labels", label_name)

    elif fold in test_folds:
        img_save = os.path.join(save_root, "test_images", image_name)
        lbl_save = os.path.join(save_root, "test_labels", label_name)

    else:
        continue

    # 复制文件
    if os.path.exists(image_path):
        shutil.copy(image_path, img_save)

    if os.path.exists(label_path):
        shutil.copy(label_path, lbl_save)

print("数据集划分完成！")