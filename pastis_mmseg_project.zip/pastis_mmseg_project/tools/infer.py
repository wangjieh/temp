import argparse
import sys
from pathlib import Path

import numpy as np
from PIL import Image

from mmseg.apis import inference_model, init_model

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from mmseg_custom.datasets import PASTIS_PALETTE


IMG_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}


def colorize_mask(mask, palette, ignore_index=255):
    h, w = mask.shape
    color = np.zeros((h, w, 3), dtype=np.uint8)
    for idx, rgb in enumerate(palette):
        color[mask == idx] = rgb
    color[mask == ignore_index] = [255, 255, 255]
    return color


def overlay_image(image_path, color_mask, alpha=0.55):
    image = Image.open(image_path).convert('RGB')
    mask_img = Image.fromarray(color_mask).resize(image.size, resample=Image.NEAREST)
    return Image.blend(image, mask_img, alpha=alpha)


def list_images(input_path):
    input_path = Path(input_path)
    if input_path.is_file():
        return [input_path]
    return sorted(p for p in input_path.rglob('*') if p.suffix.lower() in IMG_EXTS)


def parse_args():
    parser = argparse.ArgumentParser(description='Run segmentation inference and save masks/overlays.')
    parser.add_argument('config', help='Path to config file.')
    parser.add_argument('checkpoint', help='Path to trained checkpoint.')
    parser.add_argument('input', help='Image file or image folder.')
    parser.add_argument('--out-dir', default='outputs/infer', help='Output directory.')
    parser.add_argument('--device', default='cuda:0', help='Device, e.g. cuda:0 or cpu.')
    parser.add_argument('--alpha', type=float, default=0.55, help='Overlay alpha.')
    parser.add_argument('--ignore-index', type=int, default=255)
    return parser.parse_args()


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    raw_dir = out_dir / 'pred_masks'
    color_dir = out_dir / 'color_masks'
    overlay_dir = out_dir / 'overlays'
    raw_dir.mkdir(parents=True, exist_ok=True)
    color_dir.mkdir(parents=True, exist_ok=True)
    overlay_dir.mkdir(parents=True, exist_ok=True)

    model = init_model(args.config, args.checkpoint, device=args.device)

    images = list_images(args.input)
    if not images:
        raise FileNotFoundError(f'No images found: {args.input}')

    for img_path in images:
        result = inference_model(model, str(img_path))
        pred = result.pred_sem_seg.data.squeeze().detach().cpu().numpy().astype(np.uint8)

        raw_path = raw_dir / f'{img_path.stem}.png'
        color_path = color_dir / f'{img_path.stem}.png'
        overlay_path = overlay_dir / f'{img_path.stem}.jpg'

        Image.fromarray(pred).save(raw_path)
        color = colorize_mask(pred, PASTIS_PALETTE, ignore_index=args.ignore_index)
        Image.fromarray(color).save(color_path)
        overlay = overlay_image(img_path, color, alpha=args.alpha)
        overlay.save(overlay_path, quality=95)

    print(f'Done. Results saved to: {out_dir}')


if __name__ == '__main__':
    main()
