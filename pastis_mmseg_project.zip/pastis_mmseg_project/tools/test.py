import argparse
import os
import sys
from pathlib import Path

from mmengine.config import Config
from mmengine.runner import Runner


def add_project_to_path():
    project_root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(project_root))


def parse_args():
    parser = argparse.ArgumentParser(description='Test MMSeg model on PASTIS-like data.')
    parser.add_argument('config', help='Path to config file.')
    parser.add_argument('checkpoint', help='Path to checkpoint file.')
    parser.add_argument('--work-dir', default=None, help='Directory for test logs.')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action='append',
        default=[],
        help='Override config options, e.g. --cfg-options data_root=/path/to/data',
    )
    return parser.parse_args()


def flatten_cfg_options(cfg_options):
    items = []
    for group in cfg_options:
        items.extend(group)
    return items


def main():
    add_project_to_path()
    args = parse_args()

    cfg = Config.fromfile(args.config)

    if args.cfg_options:
        cfg.merge_from_dict(dict(item.split('=', 1) for item in flatten_cfg_options(args.cfg_options)))

    cfg.load_from = args.checkpoint
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    else:
        cfg.work_dir = os.path.join('./work_dirs', Path(args.config).stem + '_test')

    runner = Runner.from_cfg(cfg)
    runner.test()


if __name__ == '__main__':
    main()
