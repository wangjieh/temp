import argparse
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image


IMG_EXTS = {'.jpg', '.jpeg', 'png'}


def parse_args():
    parser = argparse.ArgumentParser(description='Check PASTIS-like dataset layout and labels.')
    parser.add_argument('--data-root', required=True, help='Dataset root.')
    parser.add_argument('--splits', nargs='+', default=['train', 'val', 'test'])
    parser.add_argument('--max-check', type=int, default=200, help='Max pairs to inspect per split.')
    return parser.parse_args()


def check_split(data_root, split, max_check):
    img_dir = data_root / f'{split}_images'
    label_dir = data_root / f'{split}_labels'

    if not img_dir.exists():
        print(f'[ERROR] Missing image folder: {img_dir}')
        return
    if not label_dir.exists():
        print(f'[ERROR] Missing label folder: {label_dir}')
        return

    images = sorted(p for p in img_dir.iterdir() if p.suffix.lower() in IMG_EXTS)
    labels = sorted(p for p in label_dir.iterdir() if p.suffix.lower() == '.png')

    img_stems = {p.stem for p in images}
    label_stems = {p.stem for p in labels}
    missing_labels = sorted(img_stems - label_stems)
    missing_images = sorted(label_stems - img_stems)

    print(f'\\n[{split}]')
    print(f'  images: {len(images)}')
    print(f'  labels: {len(labels)}')
    print(f'  missing labels: {len(missing_labels)}')
    print(f'  missing images: {len(missing_images)}')

    if missing_labels[:5]:
        print('  missing label examples:', missing_labels[:5])
    if missing_images[:5]:
        print('  missing image examples:', missing_images[:5])

    value_counter = Counter()
    shape_mismatch = []
    checked = 0

    for img_path in images:
        label_path = label_dir / f'{img_path.stem}.png'
        if not label_path.exists():
            continue

        img = Image.open(img_path)
        label = Image.open(label_path)
        if img.size != label.size:
            shape_mismatch.append((img_path.name, img.size, label.size))

        values = np.unique(np.asarray(label))
        for v in values:
            value_counter[int(v)] += 1

        checked += 1
        if checked >= max_check:
            break

    bad_values = sorted(v for v in value_counter if v not in list(range(20)))
    print(f'  checked pairs: {checked}')
    print(f'  label values found: {sorted(value_counter)}')
    print(f'  invalid values outside 0..19: {bad_values}')
    print(f'  shape mismatches: {len(shape_mismatch)}')
    if shape_mismatch[:5]:
        print('  shape mismatch examples:', shape_mismatch[:5])


def main():
    args = parse_args()
    data_root = Path(args.data_root)
    for split in args.splits:
        check_split(data_root, split, args.max_check)


if __name__ == '__main__':
    main()
