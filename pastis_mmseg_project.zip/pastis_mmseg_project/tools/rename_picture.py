import os
import shutil

src_dir = r"G:\PASTIE_elev\processed_PASTIS_R\labels"        # 原图片文件夹
dst_dir = r"G:\PASTIE_elev\processed_PASTIS_R\labels_rename"    # 新文件夹

os.makedirs(dst_dir, exist_ok=True)

for filename in os.listdir(src_dir):
    old_path = os.path.join(src_dir, filename)

    # 跳过文件夹，只处理文件
    if not os.path.isfile(old_path):
        continue

    # 只处理包含 "_" 的文件名
    if "_" not in filename:
        continue

    # 取 "_" 后面的部分，例如 xx_123.jpg -> 123.jpg
    new_filename = filename.split("_", 1)[1]

    new_path = os.path.join(dst_dir, new_filename)

    # 复制到新文件夹
    shutil.copy2(old_path, new_path)

print("处理完成")
