import argparse
import os
import sys
from pathlib import Path

from mmengine.config import Config
from mmengine.runner import Runner


def add_project_to_path():
    project_root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(project_root))


def parse_args():
    parser = argparse.ArgumentParser(description='Train MMSeg model on PASTIS-like data.')
    parser.add_argument('config', help='Path to config file.')
    parser.add_argument('--work-dir', default=None, help='Directory for logs and checkpoints.')
    parser.add_argument('--amp', action='store_true', help='Use automatic mixed precision.')
    parser.add_argument('--resume', action='store_true', help='Resume from latest checkpoint in work-dir.')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action='append',
        default=[],
        help='Override config options, e.g. --cfg-options data_root=/path/to/data train_dataloader.batch_size=4',
    )
    return parser.parse_args()


def flatten_cfg_options(cfg_options):
    items = []
    for group in cfg_options:
        items.extend(group)
    return items


def main():
    add_project_to_path()
    args = parse_args()

    cfg = Config.fromfile(args.config)

    if args.cfg_options:
        cfg.merge_from_dict(dict(item.split('=', 1) for item in flatten_cfg_options(args.cfg_options)))

    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    else:
        cfg.work_dir = os.path.join('./work_dirs', Path(args.config).stem)

    if args.resume:
        cfg.resume = True

    if args.amp:
        cfg.optim_wrapper.type = 'AmpOptimWrapper'
        cfg.optim_wrapper.loss_scale = 'dynamic'

    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
