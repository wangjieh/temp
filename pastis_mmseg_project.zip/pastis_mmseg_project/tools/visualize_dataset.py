import argparse
from pathlib import Path

import numpy as np
from PIL import Image

from mmseg_custom.datasets import PASTIS_PALETTE


IMG_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}


def colorize_label(label, palette, void_label=19):
    arr = np.asarray(label, dtype=np.uint8)
    color = np.zeros((arr.shape[0], arr.shape[1], 3), dtype=np.uint8)
    for idx, rgb in enumerate(palette):
        color[arr == idx] = rgb
    color[arr == void_label] = [255, 255, 255]
    return color


def parse_args():
    parser = argparse.ArgumentParser(description='Visualize image/label pairs.')
    parser.add_argument('--data-root', required=True, help='Dataset root.')
    parser.add_argument('--split', default='train', choices=['train', 'val', 'test'])
    parser.add_argument('--out-dir', default='outputs/gt_vis')
    parser.add_argument('--alpha', type=float, default=0.55)
    parser.add_argument('--max-num', type=int, default=50)
    return parser.parse_args()


def main():
    args = parse_args()
    data_root = Path(args.data_root)
    img_dir = data_root / f'{args.split}_images'
    label_dir = data_root / f'{args.split}_labels'
    out_dir = Path(args.out_dir) / args.split
    out_dir.mkdir(parents=True, exist_ok=True)

    images = sorted(p for p in img_dir.iterdir() if p.suffix.lower() in IMG_EXTS)

    count = 0
    for img_path in images:
        label_path = label_dir / f'{img_path.stem}.png'
        if not label_path.exists():
            continue

        image = Image.open(img_path).convert('RGB')
        label = Image.open(label_path)
        color = Image.fromarray(colorize_label(label, PASTIS_PALETTE)).resize(image.size, Image.NEAREST)
        overlay = Image.blend(image, color, alpha=args.alpha)

        canvas = Image.new('RGB', (image.width * 3, image.height))
        canvas.paste(image, (0, 0))
        canvas.paste(color, (image.width, 0))
        canvas.paste(overlay, (image.width * 2, 0))
        canvas.save(out_dir / f'{img_path.stem}.jpg', quality=95)

        count += 1
        if count >= args.max_num:
            break

    print(f'Saved {count} visualization images to: {out_dir}')


if __name__ == '__main__':
    main()
