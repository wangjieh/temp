custom_imports = dict(
    imports=[
        'mmpretrain.models',
        'mmseg_custom.datasets',
        'mmseg_custom.transforms',
    ],
    allow_failed_imports=False,
)

dataset_type = 'PastisDataset'
data_root = 'data/pastis_jpg'  # Change this to your dataset root.

num_classes = 19
ignore_index = 255
crop_size = (512, 512)

class_names = (
    'background',
    'meadow',
    'soft_winter_wheat',
    'corn',
    'winter_barley',
    'winter_rapeseed',
    'spring_barley',
    'sunflower',
    'grapevine',
    'beet',
    'winter_triticale',
    'winter_durum_wheat',
    'fruits_vegetables_flowers',
    'potatoes',
    'leguminous_fodder',
    'soybeans',
    'orchard',
    'mixed_cereal',
    'sorghum',
)

palette = [
    [0, 0, 0],
    [128, 128, 0],
    [255, 255, 0],
    [255, 165, 0],
    [190, 190, 0],
    [255, 0, 255],
    [210, 180, 140],
    [255, 215, 0],
    [128, 0, 128],
    [255, 0, 0],
    [165, 42, 42],
    [222, 184, 135],
    [255, 105, 180],
    [160, 82, 45],
    [0, 128, 0],
    [0, 255, 0],
    [34, 139, 34],
    [70, 130, 180],
    [0, 191, 255],
]

metainfo = dict(classes=class_names, palette=palette)

train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations'),
    dict(type='PastisConvertVoid', void_label=19, ignore_index=ignore_index),
    dict(type='RandomResize', scale=crop_size, ratio_range=(0.5, 2.0), keep_ratio=True),
    dict(type='RandomCrop', crop_size=crop_size, cat_max_ratio=0.75),
    dict(type='RandomFlip', prob=0.5),
    dict(type='PhotoMetricDistortion'),
    dict(type='PackSegInputs'),
]

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='Resize', scale=crop_size, keep_ratio=True),
    dict(type='LoadAnnotations'),
    dict(type='PastisConvertVoid', void_label=19, ignore_index=ignore_index),
    dict(type='PackSegInputs'),
]

train_dataloader = dict(
    batch_size=2,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='InfiniteSampler', shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(img_path='train_images', seg_map_path='train_labels'),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(img_path='val_images', seg_map_path='val_labels'),
        pipeline=test_pipeline,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(img_path='test_images', seg_map_path='test_labels'),
        pipeline=test_pipeline,
    ),
)

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU', 'mDice', 'mFscore'], ignore_index=ignore_index)
test_evaluator = val_evaluator

default_scope = 'mmseg'

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')

log_processor = dict(by_epoch=False)
log_level = 'INFO'
load_from = None
resume = False

train_cfg = dict(type='IterBasedTrainLoop', max_iters=40000, val_interval=4000)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=False),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=False,
        interval=4000,
        save_best='mIoU',
        rule='greater',
        max_keep_ckpts=3,
    ),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'),
)

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=6e-5, betas=(0.9, 0.999), weight_decay=0.01),
    clip_grad=dict(max_norm=1.0, norm_type=2),
    paramwise_cfg=dict(
        custom_keys={
            'absolute_pos_embed': dict(decay_mult=0.0),
            'relative_position_bias_table': dict(decay_mult=0.0),
            'relative_coords_table': dict(decay_mult=0.0),
            'norm': dict(decay_mult=0.0),
        }
    ),
)

param_scheduler = [
    dict(type='LinearLR', start_factor=1e-6, begin=0, end=1500, by_epoch=False),
    dict(type='PolyLR', eta_min=0.0, power=1.0, begin=1500, end=40000, by_epoch=False),
]

# Use this when you want to load a pretrained segmentation checkpoint.
# For backbone-only pretrained weights, set model.backbone.init_cfg manually.

norm_cfg = dict(type='BN', requires_grad=True)

data_preprocessor = dict(
    type='SegDataPreProcessor',
    mean=[123.675, 116.28, 103.53],
    std=[58.395, 57.12, 57.375],
    bgr_to_rgb=True,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=crop_size,
)

model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='mmpretrain.VisionTransformer',
        arch='base',
        img_size=crop_size,
        patch_size=16,
        in_channels=3,
        out_indices=(2, 5, 8, 11),
        out_type='featmap',
        drop_rate=0.0,
        drop_path_rate=0.1,
        qkv_bias=True,
        final_norm=True,
        with_cls_token=True,
        interpolate_mode='bicubic',
        init_cfg=None,
    ),
    decode_head=dict(
        type='UPerHead',
        in_channels=[768, 768, 768, 768],
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=768,
        in_index=2,
        channels=256,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)
