from setuptools import find_packages, setup

setup(
    name='pastis_mmseg_project',
    version='0.1.0',
    packages=find_packages(),
)
