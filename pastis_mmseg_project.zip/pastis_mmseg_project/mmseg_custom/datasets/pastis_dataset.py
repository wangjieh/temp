from mmseg.datasets import BaseSegDataset
from mmseg.registry import DATASETS


PASTIS_CLASSES = (
    'background',
    'meadow',
    'soft_winter_wheat',
    'corn',
    'winter_barley',
    'winter_rapeseed',
    'spring_barley',
    'sunflower',
    'grapevine',
    'beet',
    'winter_triticale',
    'winter_durum_wheat',
    'fruits_vegetables_flowers',
    'potatoes',
    'leguminous_fodder',
    'soybeans',
    'orchard',
    'mixed_cereal',
    'sorghum',
)

# 19 colors for classes 0..18. The void label 19 is ignored and not in METAINFO.
PASTIS_PALETTE = [
    [0, 0, 0],
    [128, 128, 0],
    [255, 255, 0],
    [255, 165, 0],
    [190, 190, 0],
    [255, 0, 255],
    [210, 180, 140],
    [255, 215, 0],
    [128, 0, 128],
    [255, 0, 0],
    [165, 42, 42],
    [222, 184, 135],
    [255, 105, 180],
    [160, 82, 45],
    [0, 128, 0],
    [0, 255, 0],
    [34, 139, 34],
    [70, 130, 180],
    [0, 191, 255],
]


@DATASETS.register_module()
class PastisDataset(BaseSegDataset):
    """PASTIS-like semantic segmentation dataset.

    Expected directory layout under data_root:

        train_images/*.jpg
        val_images/*.jpg
        test_images/*.jpg
        train_labels/*.png
        val_labels/*.png
        test_labels/*.png

    Labels:
        0..18: valid semantic classes
        19: void label, converted to 255 by PastisConvertVoid in pipeline

    The image and label file stems must match:
        train_images/xxx.jpg  <->  train_labels/xxx.png
    """

    METAINFO = dict(classes=PASTIS_CLASSES, palette=PASTIS_PALETTE)

    def __init__(
        self,
        img_suffix='.jpg',
        seg_map_suffix='.png',
        reduce_zero_label=False,
        **kwargs,
    ):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs,
        )
