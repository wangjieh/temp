from .pastis_dataset import PASTIS_CLASSES, PASTIS_PALETTE, PastisDataset

__all__ = ['PastisDataset', 'PASTIS_CLASSES', 'PASTIS_PALETTE']
