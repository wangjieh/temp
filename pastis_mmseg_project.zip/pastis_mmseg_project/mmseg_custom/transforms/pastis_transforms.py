import numpy as np
from mmcv.transforms import BaseTransform
from mmseg.registry import TRANSFORMS


@TRANSFORMS.register_module()
class PastisConvertVoid(BaseTransform):
    """Convert PASTIS void label to MMSeg ignore index.

    PASTIS-like labels use:
        0..18: valid classes
        19: void

    MMSegmentation commonly uses 255 as ignore_index. This transform changes
    19 -> 255 after LoadAnnotations, so the model uses num_classes=19.
    """

    def __init__(self, void_label=19, ignore_index=255):
        self.void_label = int(void_label)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        seg = results.get('gt_seg_map', None)
        if seg is not None:
            seg = np.asarray(seg).copy()
            seg[seg == self.void_label] = self.ignore_index
            results['gt_seg_map'] = seg
        return results
